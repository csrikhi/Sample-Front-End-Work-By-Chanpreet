<html>
<form action="thanks.php" method="POST">
<label>Name:<input type="text" required="" name="name"></label>
<label>Email:<input type="email" required=""  name="name"></label>
<label>Query<textarea  name="query"rows="4" cols="50">
</textarea>
</label>
<input type="submit" value="submit" name="submit">
</form>
</html>