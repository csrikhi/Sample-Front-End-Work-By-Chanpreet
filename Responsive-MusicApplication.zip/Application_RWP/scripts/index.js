var app=(function(){
	
	var menuDrop=document.getElementById("menuDrop");
	var openbarMenu=document.getElementById("openbarMenu");
	var closeCross=document.getElementById("closeCross");

	var menuOpen=function menuDisplay(){
		
		openbarMenu.addEventListener("click", function() {
			openbarMenu.style.display="none";
			closeCross.style.display="block";
			menuDrop.style.display="block";               


		});

		
		closeCross.addEventListener("click", function() {
			openbarMenu.style.display="block";
			closeCross.style.display="none";
			menuDrop.style.display="none";               

		});

		
	};
	return{
		menuOpen:menuOpen(),


	};


})();















